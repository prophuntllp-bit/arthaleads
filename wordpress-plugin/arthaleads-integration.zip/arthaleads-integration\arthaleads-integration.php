<?php
/**
 * Plugin Name:       Arthaleads Integration
 * Plugin URI:        https://arthaleads.com
 * Description:       Automatically send WordPress contact form leads to Arthaleads CRM. Supports Contact Form 7, WPForms, Elementor, Gravity Forms, Ninja Forms, Forminator, Fluent Forms, and MetForm.
 * Version:           1.0.0
 * Author:            Arthaleads
 * Author URI:        https://arthaleads.com
 * License:           GPL-2.0+
 * Text Domain:       arthaleads-integration
 */

if ( ! defined( 'WPINC' ) ) die;

define( 'ARTHALEADS_VERSION',   '1.0.0' );
define( 'ARTHALEADS_PLUGIN_ID', 'arthaleads-integration' );

require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-constants.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-status.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-options.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-api.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-loader.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-core.php';

function run_arthaleads() {
    $plugin = new Arthaleads_Core();
    $plugin->run();
}
run_arthaleads();
