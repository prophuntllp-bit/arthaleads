<?php
if ( ! defined( 'WPINC' ) ) die;

class Arthaleads_Admin {

    public function add_menu() {
        add_menu_page(
            __( 'Arthaleads', 'arthaleads-integration' ),
            __( 'Arthaleads', 'arthaleads-integration' ),
            'manage_options',
            'arthaleads-integration',
            [ $this, 'render_page' ],
            'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300"><path d="M 81.33 228.04 C76.53,226.90 69.36,222.34 66.66,218.73 C63.05,213.90 61.68,208.54 62.27,201.61 C62.84,194.98 63.99,192.31 88.99,139.50 C125.09,63.23 129.72,53.73 132.37,50.40 C133.79,48.63 137.45,45.95 140.51,44.45 C145.24,42.14 146.94,41.81 151.87,42.25 C163.03,43.27 168.29,47.91 174.96,62.65 C177.41,68.07 181.29,76.55 183.59,81.50 C200.52,117.99 217.35,157.62 216.51,158.99 C216.23,159.43 213.20,158.28 209.76,156.42 C201.54,152.01 190.75,149.61 181.96,150.24 L 175.14 150.72 L 162.66 124.11 C155.80,109.48 149.80,97.56 149.34,97.64 C148.37,97.79 142.41,109.59 129.48,137.00 C124.41,147.73 116.59,164.30 112.08,173.84 C107.58,183.38 104.03,191.57 104.20,192.05 C104.71,193.52 112.09,189.63 128.01,179.49 C154.06,162.91 166.96,158.00 184.43,158.00 C207.45,158.00 221.06,166.74 230.38,187.49 C233.03,193.40 236.95,201.99 239.10,206.59 C243.38,215.76 243.70,217.75 241.57,221.85 C239.45,225.96 236.05,227.00 224.79,227.00 C215.85,227.00 214.19,226.71 210.48,224.54 C208.17,223.19 205.58,221.01 204.72,219.70 C203.45,217.76 196.30,202.29 186.47,180.23 L 185.02 176.97 L 181.40 178.48 C175.00,181.15 164.75,188.60 154.50,198.01 C140.57,210.81 132.94,216.40 122.50,221.44 C109.16,227.89 92.15,230.62 81.33,228.04 Z" fill="white"/></svg>' ),
            30
        );
    }

    public function enqueue_assets( $hook ) {
        if ( $hook !== 'toplevel_page_arthaleads-integration' ) return;

        // Enqueue Inter font from Google Fonts via WordPress API
        wp_enqueue_style(
            'arthaleads-inter-font',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            [],
            null
        );
    }

    public function render_page() {
        require_once plugin_dir_path( __FILE__ ) . 'partials/admin-display.php';
        arthaleads_render_admin_page();
    }

    public function send_test_lead() {
        check_ajax_referer( 'arthaleads_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        $token = Arthaleads_Options::get( 'arthaleads_token' );
        if ( empty( $token ) ) {
            wp_send_json_error( [ 'message' => __( 'No token saved. Please save your settings first.', 'arthaleads-integration' ) ] );
            return;
        }

        $response = wp_remote_post( Arthaleads_Constants::API_WEBHOOK_URL, [
            'headers'  => [ 'Content-Type' => 'application/json' ],
            'body'     => wp_json_encode( [
                'token'       => $token,
                'name'        => 'Test Lead',
                'phone'       => '9999999999',
                'email'       => 'test@arthaleads.com',
                'message'     => 'Test lead from Arthaleads WordPress plugin.',
                'source_name' => Arthaleads_Options::get( 'site_name' ) ?: get_bloginfo( 'name' ),
                'form_plugin' => 'manual_test',
                'page_url'    => get_site_url(),
            ] ),
            'timeout'  => 15,
            'blocking' => true,
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => __( 'Connection failed: ', 'arthaleads-integration' ) . $response->get_error_message() ] );
            return;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! empty( $body['success'] ) ) {
            wp_send_json_success( [ 'message' => __( 'Test lead sent!', 'arthaleads-integration' ) ] );
        } else {
            wp_send_json_error( [ 'message' => __( 'API error: ', 'arthaleads-integration' ) . ( $body['message'] ?? __( 'Unknown', 'arthaleads-integration' ) ) ] );
        }
    }
}
