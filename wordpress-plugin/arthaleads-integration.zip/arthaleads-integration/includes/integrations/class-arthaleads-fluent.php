<?php
if ( ! defined( 'WPINC' ) ) die;

class Arthaleads_Fluent {

    public function handle( $insertId, $formData, $form ) {
        $flat = [];
        foreach ( $formData as $key => $val ) {
            $flat[ $key ] = is_array( $val )
                             ? implode( ', ', array_filter( array_map( 'strval', $val ) ) )
                             : (string) $val;
        }

        $norm_map = Arthaleads_CF7::build_norm_map( $flat );
        [ $name, $phone, $email, $message, $remaining ] = Arthaleads_CF7::extract_fields( $norm_map );
        $message = Arthaleads_CF7::append_extras( $message, $remaining );

        ( new Arthaleads_API( 'fluent_form' ) )->send_lead( [
            'name'      => $name,
            'phone'     => $phone,
            'email'     => $email,
            'message'   => $message,
            'form_name' => $form->title ?? '',
        ] );
    }
}
