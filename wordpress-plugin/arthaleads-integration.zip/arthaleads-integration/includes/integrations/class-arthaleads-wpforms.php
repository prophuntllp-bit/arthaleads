<?php
if ( ! defined( 'WPINC' ) ) die;

class Arthaleads_WPForms {

    public function handle( $fields, $entry, $form_data ) {
        $flat = [];
        foreach ( $fields as $field ) {
            $label = $field['name'] ?? ( 'field_' . ( $field['id'] ?? count( $flat ) ) );
            $val   = is_array( $field['value'] ?? '' )
                     ? implode( ', ', array_filter( array_map( 'strval', $field['value'] ) ) )
                     : (string) ( $field['value'] ?? '' );
            $flat[ $label ] = $val;
        }

        $norm_map = Arthaleads_CF7::build_norm_map( $flat );
        [ $name, $phone, $email, $message, $remaining ] = Arthaleads_CF7::extract_fields( $norm_map );

        $message    = Arthaleads_CF7::append_extras( $message, $remaining );
        $form_title = $form_data['settings']['form_title'] ?? '';

        ( new Arthaleads_API( 'wpforms' ) )->send_lead( [
            'name'      => $name,
            'phone'     => $phone,
            'email'     => $email,
            'message'   => $message,
            'form_name' => $form_title,
        ] );
    }
}
