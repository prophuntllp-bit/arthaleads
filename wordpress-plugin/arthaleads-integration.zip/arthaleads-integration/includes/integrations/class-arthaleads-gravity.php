<?php
if ( ! defined( 'WPINC' ) ) die;

class Arthaleads_Gravity {

    public function handle( $entry, $form ) {
        $flat = [];
        foreach ( $form['fields'] as $field ) {
            if ( is_a( $field, 'GF_Field_Name' ) ) {
                $val = trim( rgar( $entry, $field->id . '.3' ) . ' ' . rgar( $entry, $field->id . '.6' ) );
            } else {
                $raw = rgar( $entry, $field->id );
                $val = is_array( $raw )
                       ? implode( ', ', array_filter( array_map( 'strval', $raw ) ) )
                       : trim( (string) $raw );
            }
            $label = $field->label ?? ( 'field_' . $field->id );
            $flat[ $label ] = $val;
        }

        $norm_map = Arthaleads_CF7::build_norm_map( $flat );
        [ $name, $phone, $email, $message, $remaining ] = Arthaleads_CF7::extract_fields( $norm_map );
        $message = Arthaleads_CF7::append_extras( $message, $remaining );

        ( new Arthaleads_API( 'gravity_form' ) )->send_lead( [
            'name'      => $name,
            'phone'     => $phone,
            'email'     => $email,
            'message'   => $message,
            'form_name' => $form['title'] ?? '',
        ] );
    }
}
