<?php
if ( ! defined( 'WPINC' ) ) die;

class Arthaleads_Elementor {

    public function handle( $record, $handler ) {
        $flat = [];
        foreach ( $record->get( 'fields' ) as $id => $field ) {
            $val = is_array( $field ) ? Arthaleads_CF7::scalar( $field['value'] ?? '' ) : trim( (string) $field );
            // Index by both field ID and label for best chance of matching
            $flat[ $id ] = $val;
            $title = $field['title'] ?? ( $field['label'] ?? '' );
            if ( $title ) $flat[ $title ] = $val;
        }

        $norm_map = Arthaleads_CF7::build_norm_map( $flat );
        [ $name, $phone, $email, $message, $remaining ] = Arthaleads_CF7::extract_fields( $norm_map );

        // Last resort: use first non-empty value as name
        if ( empty( $name ) && empty( $phone ) && empty( $email ) ) {
            $vals = array_values( array_filter( $flat ) );
            $name = $vals[0] ?? 'Website Lead';
            unset( $remaining[ array_key_first( $remaining ) ] );
        }

        $message = Arthaleads_CF7::append_extras( $message, $remaining );

        $form_settings = $record->get( 'form_settings' );
        $form_name     = $form_settings['form_name'] ?? '';

        ( new Arthaleads_API( 'elementor_form' ) )->send_lead( [
            'name'      => $name,
            'phone'     => $phone,
            'email'     => $email,
            'message'   => $message,
            'form_name' => $form_name,
        ] );
    }
}
