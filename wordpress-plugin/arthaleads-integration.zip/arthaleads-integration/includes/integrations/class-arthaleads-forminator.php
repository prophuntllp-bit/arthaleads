<?php
if ( ! defined( 'WPINC' ) ) die;

class Arthaleads_Forminator {

    public function handle( $module_id, $response ) {
        if ( empty( $response['entry'] ) ) return;
        $meta = (array) $response['entry']->meta_data;

        $flat = [];
        foreach ( $meta as $key => $item ) {
            $val = is_array( $item ) && isset( $item['value'] ) ? $item['value'] : $item;
            $val = is_array( $val ) ? implode( ', ', array_filter( array_map( 'strval', $val ) ) ) : (string) $val;
            $flat[ $key ] = trim( $val );
        }

        $norm_map = Arthaleads_CF7::build_norm_map( $flat );
        [ $name, $phone, $email, $message, $remaining ] = Arthaleads_CF7::extract_fields( $norm_map );
        $message = Arthaleads_CF7::append_extras( $message, $remaining );

        ( new Arthaleads_API( 'forminator_form' ) )->send_lead( [
            'name'    => $name,
            'phone'   => $phone,
            'email'   => $email,
            'message' => $message,
        ] );
    }
}
