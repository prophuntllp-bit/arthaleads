=== Arthaleads CRM Integration ===
Contributors: arthaleads
Tags: crm, leads, contact form, real estate, metform, elementor, wpforms, cf7
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically send WordPress contact form leads to Arthaleads CRM. Zero code, one token, all your forms.

== Description ==

**Arthaleads CRM Integration** connects your WordPress contact forms to [Arthaleads CRM](https://arthaleads.com) and automatically sends every lead submission directly into your CRM pipeline — in real time.

Built for real estate businesses, agencies, and anyone managing leads from multiple websites and forms.

= How it works =

1. Install and activate this plugin
2. Go to **Arthaleads CRM** in your WordPress sidebar
3. Paste your account token from [crm.arthaleads.com → Automations → WordPress / Website](https://crm.arthaleads.com/automations)
4. Toggle on the contact forms you use
5. Save — leads start flowing instantly

= Supported Form Plugins =

* ✅ Contact Form 7
* ✅ WPForms (Free & Pro)
* ✅ Elementor Pro Forms
* ✅ Gravity Forms
* ✅ Ninja Forms
* ✅ Forminator
* ✅ Fluent Forms
* ✅ MetForm

= Features =

* **Auto-detect installed forms** — the plugin scans your installed plugins and shows only what you have
* **Per-form source tracking** — each lead includes the exact form name it came from
* **One token, multiple sites** — use the same Arthaleads account across all your websites
* **No coding required** — fully managed from the WordPress admin
* **Lightweight** — no jQuery, no external scripts loaded on the front end

= Data & Privacy =

This plugin transmits lead data (name, phone, email, message, form name, page URL) to the Arthaleads CRM API at `https://api.arthaleads.com` when a contact form is submitted. This service is operated by Arthaleads (https://arthaleads.com). Only sites that have entered a valid Arthaleads account token will transmit data. No data is transmitted without an active token configured by the site administrator.

See the [Arthaleads Privacy Policy](https://arthaleads.com/privacy) for details.

== Installation ==

= Automatic (Recommended) =

1. In your WordPress admin go to **Plugins → Add New**
2. Search for **Arthaleads**
3. Click **Install Now**, then **Activate**
4. Click **Arthaleads CRM** in the left sidebar
5. Paste your token from [crm.arthaleads.com](https://crm.arthaleads.com/automations)
6. Toggle on your contact forms and click **Save Settings**

= Manual =

1. Download the plugin ZIP from WordPress.org
2. Go to **Plugins → Add New → Upload Plugin**
3. Upload the ZIP and click **Install Now**
4. Activate and follow steps 4–6 above

== Frequently Asked Questions ==

= Where do I get my token? =

Log in to [Arthaleads CRM](https://crm.arthaleads.com), go to **Automations**, click **WordPress / Website**, and copy the token shown there. If you don't have an account yet, sign up at [arthaleads.com](https://arthaleads.com).

= Does this work with multiple websites? =

Yes. Install the plugin on each website and use the same Arthaleads token. Each site will appear separately in your CRM under Automations, showing its website name and active forms.

= Which form plugins are supported? =

Contact Form 7, WPForms, Elementor Pro Forms, Gravity Forms, Ninja Forms, Forminator, Fluent Forms, and MetForm. More integrations will be added in future updates.

= What data is sent to Arthaleads? =

When a form is submitted, the plugin sends: lead name, phone number, email address, message, form name, page URL, and your site name. No other data is collected or transmitted.

= Does this slow down my website? =

No. Lead data is sent asynchronously (fire-and-forget) after the form submission is processed, so it never adds latency to your visitor's experience.

= What if my form plugin is not listed? =

Toggle on the forms you use. If your form plugin is not yet supported, [contact us](mailto:support@arthaleads.com) and we will add it in the next release.

== Screenshots ==

1. The Arthaleads CRM settings page — paste your token and toggle your forms on
2. Leads appearing in Arthaleads CRM with form source automatically labelled
3. Auto-detected form plugins with connection status badges

== Changelog ==

= 1.0.0 =
* Initial release
* Support for Contact Form 7, WPForms, Elementor Pro Forms, Gravity Forms, Ninja Forms, Forminator, Fluent Forms, MetForm
* Auto-detect installed form plugins
* Per-form source label (shows exact form name in CRM)
* One-click test lead from admin panel
* Auto-registration ping on token save (syncs site name and active forms to CRM)

== Upgrade Notice ==

= 1.0.0 =
Initial release.
