<?php
/**
 * Plugin Name:       Arthaleads CRM: Contact Form Lead Capture
 * Plugin URI:        https://www.arthaleads.com/wordpress-plugin
 * Description:       Send WordPress form leads directly into Arthaleads CRM — zero code, one token. Supports Contact Form 7, WPForms, Elementor Pro Forms, Gravity Forms, Ninja Forms, Forminator, Fluent Forms, and MetForm.
 * Version:           1.0.9
 * Author:            Vistrow Technologies
 * Author URI:        https://www.vistrow.com/
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       arthaleads
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'WPINC' ) ) die;

define( 'ARTHALEADS_VERSION',   '1.0.9' );
define( 'ARTHALEADS_PLUGIN_ID', 'arthaleads-integration' );
define( 'ARTHALEADS_PLUGIN_FILE', __FILE__ );

require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-constants.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-status.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-options.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-api.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-review-notice.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-loader.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-arthaleads-core.php';

function arthaleads_run() {
    $plugin = new Arthaleads_Core();
    $plugin->run();
}
arthaleads_run();
